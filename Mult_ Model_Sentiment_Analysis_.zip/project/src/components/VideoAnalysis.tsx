import React, { useState, useRef } from 'react';
import { Video, Upload, Play, Square, BarChart3 } from 'lucide-react';
import { extractTextFromVideo, analyzeSentiment, SentimentResult } from '../utils/sentimentAnalysis';

interface VideoAnalysisProps {
  onAnalysisComplete: (result: SentimentResult, extractedText: string) => void;
}

export const VideoAnalysis: React.FC<VideoAnalysisProps> = ({ onAnalysisComplete }) => {
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type.startsWith('video/')) {
      setVideoFile(file);
      setVideoUrl(URL.createObjectURL(file));
    }
  };

  const togglePlayback = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
        setIsPlaying(false);
      } else {
        videoRef.current.play();
        setIsPlaying(true);
      }
    }
  };

  const handleAnalyze = async () => {
    if (!videoFile) return;

    setIsAnalyzing(true);
    
    try {
      const extractedText = await extractTextFromVideo(videoFile);
      const sentimentResult = analyzeSentiment(extractedText);
      onAnalysisComplete(sentimentResult, extractedText);
    } catch (error) {
      console.error('Error analyzing video:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-purple-100 rounded-lg">
          <Video className="w-6 h-6 text-purple-600" />
        </div>
        <div>
          <h2 className="text-xl font-semibold text-gray-800">Video Analysis</h2>
          <p className="text-sm text-gray-600">Upload video to extract and analyze speech sentiment</p>
        </div>
      </div>

      <div className="space-y-4">
        {/* Upload Section */}
        <div className="border-2 border-dashed border-gray-200 rounded-lg p-6 text-center hover:border-purple-300 transition-colors duration-200">
          <input
            ref={fileInputRef}
            type="file"
            accept="video/*"
            onChange={handleFileUpload}
            className="hidden"
          />
          
          <div className="space-y-4">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-2 px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-all duration-200 mx-auto"
            >
              <Upload className="w-5 h-5" />
              Upload Video File
            </button>
            
            <p className="text-sm text-gray-500">
              Supported formats: MP4, WebM, AVI, MOV
            </p>
            
            {videoFile && (
              <div className="bg-gray-50 rounded-lg p-4 text-left">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <div className="font-medium text-gray-700 text-sm">
                      {videoFile.name}
                    </div>
                    <div className="text-xs text-gray-500">
                      {formatFileSize(videoFile.size)}
                    </div>
                  </div>
                  <button
                    onClick={togglePlayback}
                    className="flex items-center gap-1 px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700 transition-colors duration-200"
                  >
                    {isPlaying ? <Square className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                    {isPlaying ? 'Pause' : 'Play'}
                  </button>
                </div>
                
                {videoUrl && (
                  <video
                    ref={videoRef}
                    src={videoUrl}
                    onPlay={() => setIsPlaying(true)}
                    onPause={() => setIsPlaying(false)}
                    onEnded={() => setIsPlaying(false)}
                    className="w-full max-h-48 bg-black rounded-lg"
                    controls
                  />
                )}
              </div>
            )}
          </div>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <div className="p-1 bg-blue-100 rounded-full">
              <Video className="w-4 h-4 text-blue-600" />
            </div>
            <div className="text-sm text-blue-800">
              <p className="font-medium mb-1">How it works:</p>
              <ul className="space-y-1 text-xs">
                <li>• Video audio is extracted and processed</li>
                <li>• Speech is converted to text using AI</li>
                <li>• Text sentiment is analyzed and scored</li>
                <li>• Results show emotional tone and confidence</li>
              </ul>
            </div>
          </div>
        </div>

        <button
          onClick={handleAnalyze}
          disabled={!videoFile || isAnalyzing}
          className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-all duration-200 transform hover:scale-105 active:scale-95"
        >
          {isAnalyzing ? (
            <>
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              Processing Video...
            </>
          ) : (
            <>
              <BarChart3 className="w-5 h-5" />
              Analyze Video Sentiment
            </>
          )}
        </button>
      </div>
    </div>
  );
};