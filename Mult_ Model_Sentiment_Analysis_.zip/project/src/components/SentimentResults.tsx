import React, { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, Minus, BarChart3, MessageSquare, Target, Volume2, VolumeX, Settings } from 'lucide-react';
import { SentimentResult } from '../utils/sentimentAnalysis';
import { speakWithBrowserTTS, stopSpeech, getAvailableVoices } from '../utils/textToSpeech';
import { VoiceSelector } from './VoiceSelector';
import { ControlPanel } from './ControlPanel';

interface SentimentResultsProps {
  result: SentimentResult;
  extractedText?: string;
  analysisType: 'text' | 'audio' | 'video';
}

export const SentimentResults: React.FC<SentimentResultsProps> = ({ 
  result, 
  extractedText, 
  analysisType 
}) => {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [showVoiceControls, setShowVoiceControls] = useState(false);
  const [selectedVoice, setSelectedVoice] = useState('');
  const [voiceSettings, setVoiceSettings] = useState({
    rate: 0.9,
    pitch: 1.0,
    volume: 1.0
  });

  useEffect(() => {
    // Set default voice when component mounts
    getAvailableVoices().then(voices => {
      if (voices.length > 0 && !selectedVoice) {
        // Try to find an English voice, otherwise use the first available
        const englishVoice = voices.find(voice => voice.lang.startsWith('en'));
        setSelectedVoice(englishVoice?.voiceURI || voices[0].voiceURI);
      }
    });
  }, [selectedVoice]);

  const getSentimentColor = (label: string) => {
    switch (label) {
      case 'positive':
        return 'text-green-600 bg-green-50 border-green-200';
      case 'negative':
        return 'text-red-600 bg-red-50 border-red-200';
      default:
        return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getSentimentIcon = (label: string) => {
    switch (label) {
      case 'positive':
        return <TrendingUp className="w-6 h-6 text-green-600" />;
      case 'negative':
        return <TrendingDown className="w-6 h-6 text-red-600" />;
      default:
        return <Minus className="w-6 h-6 text-gray-600" />;
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 70) return 'text-green-600 bg-green-100';
    if (confidence >= 40) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const getAnalysisTypeIcon = () => {
    switch (analysisType) {
      case 'audio':
        return '🎵';
      case 'video':
        return '🎬';
      default:
        return '📝';
    }
  };

  const generateSpeechText = () => {
    const sentimentDescription = result.label === 'positive' 
      ? 'positive sentiment' 
      : result.label === 'negative' 
      ? 'negative sentiment' 
      : 'neutral sentiment';

    const confidenceLevel = result.confidence >= 70 
      ? 'high confidence' 
      : result.confidence >= 40 
      ? 'medium confidence' 
      : 'low confidence';

    let speechText = `Analysis complete. The ${analysisType} shows ${sentimentDescription} with a score of ${result.score} and ${confidenceLevel} at ${result.confidence} percent.`;

    if (result.positive.length > 0) {
      speechText += ` Positive words detected include: ${result.positive.slice(0, 3).join(', ')}.`;
    }

    if (result.negative.length > 0) {
      speechText += ` Negative words detected include: ${result.negative.slice(0, 3).join(', ')}.`;
    }

    if (extractedText) {
      speechText += ` The extracted text was: "${extractedText}"`;
    }

    return speechText;
  };

  const handleSpeak = async () => {
    if (isSpeaking) {
      stopSpeech();
      setIsSpeaking(false);
      return;
    }

    try {
      setIsSpeaking(true);
      const speechText = generateSpeechText();
      
      // Set the selected voice
      const voices = await getAvailableVoices();
      const voice = voices.find(v => v.voiceURI === selectedVoice);
      
      if (voice && 'speechSynthesis' in window) {
        speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(speechText);
        utterance.voice = voice;
        utterance.rate = voiceSettings.rate;
        utterance.pitch = voiceSettings.pitch;
        utterance.volume = voiceSettings.volume;
        
        utterance.onend = () => setIsSpeaking(false);
        utterance.onerror = () => setIsSpeaking(false);
        
        speechSynthesis.speak(utterance);
      } else {
        await speakWithBrowserTTS(speechText, voiceSettings);
        setIsSpeaking(false);
      }
    } catch (error) {
      console.error('Speech error:', error);
      setIsSpeaking(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 border-b border-gray-100">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white rounded-lg shadow-sm">
              <BarChart3 className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h3 className="text-xl font-semibold text-gray-800">
                Sentiment Analysis Results {getAnalysisTypeIcon()}
              </h3>
              <p className="text-sm text-gray-600 capitalize">
                {analysisType} analysis completed
              </p>
            </div>
          </div>
          
          {/* Voice Controls */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowVoiceControls(!showVoiceControls)}
              className="p-2 bg-white rounded-lg shadow-sm hover:bg-gray-50 transition-colors duration-200"
              title="Voice Settings"
            >
              <Settings className="w-5 h-5 text-gray-600" />
            </button>
            
            <button
              onClick={handleSpeak}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                isSpeaking
                  ? 'bg-red-600 text-white hover:bg-red-700'
                  : 'bg-blue-600 text-white hover:bg-blue-700'
              }`}
            >
              {isSpeaking ? (
                <>
                  <VolumeX className="w-4 h-4" />
                  Stop
                </>
              ) : (
                <>
                  <Volume2 className="w-4 h-4" />
                  Listen
                </>
              )}
            </button>
          </div>
        </div>
        
        {/* Voice Controls Panel */}
        {showVoiceControls && (
          <div className="mt-4 p-4 bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Voice Selection
                </label>
                <VoiceSelector
                  selectedVoice={selectedVoice}
                  onVoiceChange={setSelectedVoice}
                />
              </div>
              
              <ControlPanel
                rate={voiceSettings.rate}
                pitch={voiceSettings.pitch}
                volume={voiceSettings.volume}
                onRateChange={(rate) => setVoiceSettings(prev => ({ ...prev, rate }))}
                onPitchChange={(pitch) => setVoiceSettings(prev => ({ ...prev, pitch }))}
                onVolumeChange={(volume) => setVoiceSettings(prev => ({ ...prev, volume }))}
              />
            </div>
          </div>
        )}
      </div>

      <div className="p-6 space-y-6">
        {/* Main Sentiment Display */}
        <div className="grid md:grid-cols-3 gap-4">
          <div className={`p-4 rounded-lg border-2 ${getSentimentColor(result.label)}`}>
            <div className="flex items-center gap-3 mb-2">
              {getSentimentIcon(result.label)}
              <span className="font-semibold text-lg capitalize">
                {result.label}
              </span>
            </div>
            <div className="text-sm opacity-75">
              Primary sentiment detected
            </div>
          </div>

          <div className="p-4 bg-blue-50 border-2 border-blue-200 rounded-lg">
            <div className="flex items-center gap-3 mb-2">
              <Target className="w-6 h-6 text-blue-600" />
              <span className="font-semibold text-lg text-blue-600">
                {result.score > 0 ? '+' : ''}{result.score}
              </span>
            </div>
            <div className="text-sm text-blue-600 opacity-75">
              Sentiment score
            </div>
          </div>

          <div className={`p-4 rounded-lg border-2 ${getConfidenceColor(result.confidence)}`}>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-6 h-6 rounded-full bg-current opacity-20"></div>
              <span className="font-semibold text-lg">
                {result.confidence}%
              </span>
            </div>
            <div className="text-sm opacity-75">
              Confidence level
            </div>
          </div>
        </div>

        {/* Detailed Metrics */}
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h4 className="font-semibold text-gray-800 flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              Detailed Metrics
            </h4>
            
            <div className="space-y-3">
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                <span className="text-sm font-medium text-gray-700">Comparative Score</span>
                <span className="text-sm font-semibold text-gray-900">
                  {result.comparative.toFixed(3)}
                </span>
              </div>
              
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                <span className="text-sm font-medium text-gray-700">Total Words</span>
                <span className="text-sm font-semibold text-gray-900">
                  {result.tokens.length}
                </span>
              </div>
              
              <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                <span className="text-sm font-medium text-green-700">Positive Words</span>
                <span className="text-sm font-semibold text-green-900">
                  {result.positive.length}
                </span>
              </div>
              
              <div className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                <span className="text-sm font-medium text-red-700">Negative Words</span>
                <span className="text-sm font-semibold text-red-900">
                  {result.negative.length}
                </span>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="font-semibold text-gray-800 flex items-center gap-2">
              <MessageSquare className="w-4 h-4" />
              Key Words
            </h4>
            
            {result.positive.length > 0 && (
              <div>
                <h5 className="text-sm font-medium text-green-700 mb-2">Positive Words</h5>
                <div className="flex flex-wrap gap-2">
                  {result.positive.slice(0, 10).map((word, index) => (
                    <span
                      key={index}
                      className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full"
                    >
                      {word}
                    </span>
                  ))}
                </div>
              </div>
            )}
            
            {result.negative.length > 0 && (
              <div>
                <h5 className="text-sm font-medium text-red-700 mb-2">Negative Words</h5>
                <div className="flex flex-wrap gap-2">
                  {result.negative.slice(0, 10).map((word, index) => (
                    <span
                      key={index}
                      className="px-2 py-1 bg-red-100 text-red-800 text-xs rounded-full"
                    >
                      {word}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Extracted Text (for audio/video) */}
        {extractedText && (
          <div className="space-y-3">
            <h4 className="font-semibold text-gray-800 flex items-center gap-2">
              <MessageSquare className="w-4 h-4" />
              Extracted Text
            </h4>
            <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
              <p className="text-gray-700 text-sm leading-relaxed">
                "{extractedText}"
              </p>
            </div>
          </div>
        )}

        {/* Confidence Indicator */}
        <div className="space-y-3">
          <h4 className="font-semibold text-gray-800">Confidence Breakdown</h4>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div
              className={`h-3 rounded-full transition-all duration-500 ${
                result.confidence >= 70 
                  ? 'bg-green-500' 
                  : result.confidence >= 40 
                  ? 'bg-yellow-500' 
                  : 'bg-red-500'
              }`}
              style={{ width: `${result.confidence}%` }}
            ></div>
          </div>
          <div className="flex justify-between text-xs text-gray-500">
            <span>Low</span>
            <span>Medium</span>
            <span>High</span>
          </div>
        </div>
      </div>
    </div>
  );
};