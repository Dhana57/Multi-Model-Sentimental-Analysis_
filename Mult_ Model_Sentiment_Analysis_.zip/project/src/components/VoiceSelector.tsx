import React, { useEffect, useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { getAvailableVoices } from '../utils/textToSpeech';

interface VoiceSelectorProps {
  selectedVoice: string;
  onVoiceChange: (voiceURI: string) => void;
}

export const VoiceSelector: React.FC<VoiceSelectorProps> = ({ selectedVoice, onVoiceChange }) => {
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    getAvailableVoices().then(setVoices);
  }, []);

  const selectedVoiceObj = voices.find(voice => voice.voiceURI === selectedVoice);

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between px-4 py-3 bg-white border border-gray-200 rounded-lg hover:border-blue-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
      >
        <span className="text-gray-700">
          {selectedVoiceObj ? `${selectedVoiceObj.name} (${selectedVoiceObj.lang})` : 'Select a voice'}
        </span>
        <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute z-10 w-full mt-2 bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
          {voices.map((voice) => (
            <button
              key={voice.voiceURI}
              type="button"
              onClick={() => {
                onVoiceChange(voice.voiceURI);
                setIsOpen(false);
              }}
              className={`w-full text-left px-4 py-3 hover:bg-blue-50 transition-colors duration-150 ${
                selectedVoice === voice.voiceURI ? 'bg-blue-100 text-blue-700' : 'text-gray-700'
              }`}
            >
              <div className="font-medium">{voice.name}</div>
              <div className="text-sm text-gray-500">{voice.lang}</div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};