import Sentiment from 'sentiment';

const sentiment = new Sentiment();

export interface SentimentResult {
  score: number;
  comparative: number;
  calculation: Array<{ [key: string]: number }>;
  tokens: string[];
  words: string[];
  positive: string[];
  negative: string[];
  label: 'positive' | 'negative' | 'neutral';
  confidence: number;
}

export const analyzeSentiment = (text: string): SentimentResult => {
  const result = sentiment.analyze(text);
  
  // Determine label based on score
  let label: 'positive' | 'negative' | 'neutral';
  if (result.score > 0) {
    label = 'positive';
  } else if (result.score < 0) {
    label = 'negative';
  } else {
    label = 'neutral';
  }

  // Calculate confidence based on comparative score
  const confidence = Math.min(Math.abs(result.comparative) * 100, 100);

  return {
    ...result,
    label,
    confidence: Math.round(confidence)
  };
};

export const extractTextFromAudio = async (audioFile: File): Promise<string> => {
  // This would typically use a speech-to-text service like Google Speech-to-Text
  // For demo purposes, we'll simulate the process
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      // Simulate extracted text from audio
      const sampleTexts = [
        "I'm really excited about this new project. It's going to be amazing!",
        "This is frustrating. Nothing seems to be working properly today.",
        "The weather is okay today. Nothing special to report.",
        "I love spending time with my family. They make me so happy!",
        "I'm disappointed with the service. It could be much better."
      ];
      
      const randomText = sampleTexts[Math.floor(Math.random() * sampleTexts.length)];
      resolve(randomText);
    }, 2000);
  });
};

export const extractTextFromVideo = async (videoFile: File): Promise<string> => {
  // This would typically use a video processing service to extract audio and then convert to text
  // For demo purposes, we'll simulate the process
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      // Simulate extracted text from video
      const sampleTexts = [
        "Welcome to our presentation. We're thrilled to share these exciting updates with you.",
        "The quarterly results are disappointing. We need to improve our strategy significantly.",
        "Today's meeting covered the usual topics. Everything is proceeding as planned.",
        "This breakthrough discovery will revolutionize how we approach the problem!",
        "Unfortunately, we're facing some challenges that require immediate attention."
      ];
      
      const randomText = sampleTexts[Math.floor(Math.random() * sampleTexts.length)];
      resolve(randomText);
    }, 3000);
  });
};