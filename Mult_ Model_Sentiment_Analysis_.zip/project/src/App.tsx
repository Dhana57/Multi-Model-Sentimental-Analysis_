import React, { useState } from 'react';
import { Brain, FileText, Mic, Video, BarChart3 } from 'lucide-react';
import { TextAnalysis } from './components/TextAnalysis';
import { AudioAnalysis } from './components/AudioAnalysis';
import { VideoAnalysis } from './components/VideoAnalysis';
import { SentimentResults } from './components/SentimentResults';
import { SentimentResult } from './utils/sentimentAnalysis';

type AnalysisType = 'text' | 'audio' | 'video';

function App() {
  const [activeTab, setActiveTab] = useState<AnalysisType>('text');
  const [analysisResult, setAnalysisResult] = useState<{
    result: SentimentResult;
    extractedText?: string;
    type: AnalysisType;
  } | null>(null);

  const handleAnalysisComplete = (result: SentimentResult, extractedText?: string) => {
    setAnalysisResult({
      result,
      extractedText,
      type: activeTab
    });
  };

  const tabs = [
    {
      id: 'text' as AnalysisType,
      label: 'Text Analysis',
      icon: FileText,
      color: 'blue',
      description: 'Analyze written text'
    },
    {
      id: 'audio' as AnalysisType,
      label: 'Audio Analysis',
      icon: Mic,
      color: 'green',
      description: 'Analyze speech from audio'
    },
    {
      id: 'video' as AnalysisType,
      label: 'Video Analysis',
      icon: Video,
      color: 'purple',
      description: 'Extract and analyze video speech'
    }
  ];

  const getTabColors = (color: string, isActive: boolean) => {
    const colors = {
      blue: isActive 
        ? 'bg-blue-100 text-blue-700 border-blue-300' 
        : 'bg-white text-gray-600 border-gray-200 hover:bg-blue-50 hover:text-blue-600',
      green: isActive 
        ? 'bg-green-100 text-green-700 border-green-300' 
        : 'bg-white text-gray-600 border-gray-200 hover:bg-green-50 hover:text-green-600',
      purple: isActive 
        ? 'bg-purple-100 text-purple-700 border-purple-300' 
        : 'bg-white text-gray-600 border-gray-200 hover:bg-purple-50 hover:text-purple-600'
    };
    return colors[color as keyof typeof colors];
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="p-3 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full">
              <Brain className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              SentimentScope
            </h1>
          </div>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Advanced AI-powered sentiment analysis for text, audio, and video content. 
            Understand emotions, opinions, and attitudes with precision and confidence.
          </p>
        </div>

        {/* Navigation Tabs */}
        <div className="flex flex-wrap justify-center gap-4 mb-8">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-3 px-6 py-4 rounded-xl border-2 transition-all duration-200 transform hover:scale-105 ${getTabColors(tab.color, isActive)}`}
              >
                <Icon className="w-5 h-5" />
                <div className="text-left">
                  <div className="font-semibold">{tab.label}</div>
                  <div className="text-xs opacity-75">{tab.description}</div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Analysis Input */}
          <div className="space-y-6">
            {activeTab === 'text' && (
              <TextAnalysis onAnalysisComplete={handleAnalysisComplete} />
            )}
            {activeTab === 'audio' && (
              <AudioAnalysis onAnalysisComplete={handleAnalysisComplete} />
            )}
            {activeTab === 'video' && (
              <VideoAnalysis onAnalysisComplete={handleAnalysisComplete} />
            )}

            {/* Features Info */}
            <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-indigo-100 rounded-lg">
                  <BarChart3 className="w-5 h-5 text-indigo-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-800">Analysis Features</h3>
              </div>
              
              <div className="grid sm:grid-cols-2 gap-4 text-sm">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-gray-700">Real-time sentiment scoring</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span className="text-gray-700">Confidence measurement</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                    <span className="text-gray-700">Key word identification</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                    <span className="text-gray-700">Multi-format support</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                    <span className="text-gray-700">Detailed breakdowns</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-teal-500 rounded-full"></div>
                    <span className="text-gray-700">Visual result display</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Results */}
          <div className="space-y-6">
            {analysisResult ? (
              <SentimentResults
                result={analysisResult.result}
                extractedText={analysisResult.extractedText}
                analysisType={analysisResult.type}
              />
            ) : (
              <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-100 text-center">
                <div className="p-4 bg-gray-100 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                  <BarChart3 className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-semibold text-gray-800 mb-2">
                  Ready for Analysis
                </h3>
                <p className="text-gray-600">
                  Select your preferred analysis method and input your content to get started. 
                  Results will appear here with detailed sentiment insights.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="mt-12 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full shadow-sm border border-gray-200">
            <Brain className="w-4 h-4 text-blue-600" />
            <span className="text-sm text-gray-600">
              Powered by advanced sentiment analysis algorithms
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;